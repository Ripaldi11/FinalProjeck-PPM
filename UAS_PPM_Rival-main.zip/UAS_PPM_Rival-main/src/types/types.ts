export type Product = {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  customer: string;
  created_at: string;
};
