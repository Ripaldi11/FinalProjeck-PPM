// src/navigation/AuthNavigator.js
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import LoginScreen from '../screens/authScreen/Login';
import RegisterScreen from '../screens/authScreen/Register';
import MainNavigator from './MainNavigator';
import OrderScreen from '../screens/OrderScreen';
import ProductScreen from '../screens/ProductScreen';
import EditProduct from '../screens/EditProduct';
import AddProduct from '../screens/AddProduct';
import ProfileScreen from '../screens/ProfileScreen';

const Stack = createStackNavigator();

const AuthNavigator = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
      <Stack.Screen name="Main" component={MainNavigator} />
      <Stack.Screen name="Order" component={OrderScreen} />
      <Stack.Screen name="Product" component={ProductScreen} />
      <Stack.Screen name="EditProduct" component={EditProduct} />
      <Stack.Screen name="AddProduct" component={AddProduct} />
      <Stack.Screen name="ProfileScreen" component={ProfileScreen} />
    </Stack.Navigator>
  );
};

export default AuthNavigator;
