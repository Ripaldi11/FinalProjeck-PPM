import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

const OrderScreen = () => {
  const [products, setProducts] = useState([
    { id: '1', name: 'Seblak ceker badak', price: 5000, quantity: 1 },
    { id: '2', name: 'Seblak ceker badak', price: 8000, quantity: 1 },
    { id: '3', name: 'Mizon', price: 10000, quantity: 0 },
    { id: '4', name: 'Corneto', price: 10000, quantity: 0 },
    { id: '5', name: 'Citatto', price: 10000, quantity: 0 },
    { id: '6', name: 'Pocariswet', price: 10000, quantity: 0 },
    { id: '7', name: 'Pocariswet', price: 10000, quantity: 0 },
  ]);

  const [categories, setCategories] = useState([
    { id: '1', name: 'All' },
    { id: '2', name: 'Minuman' },
    { id: '3', name: 'Cemilan' },
    { id: '4', name: 'Mie' },
    { id: '5', name: 'Permen' },
    { id: '6', name: 'Ice' },
  ]);

  const [selectedCategory, setSelectedCategory] = useState('All');

  const renderProduct = ({ item }) => (
    <View style={styles.productRow}>
      <View>
        <Text style={styles.productName}>{item.name}</Text>
        <Text style={styles.productPrice}>Rp. {item.price.toLocaleString('id-ID')},00</Text>
      </View>
      <View style={styles.productActions}>
        {item.quantity > 0 && <Text style={styles.productQuantity}>{item.quantity}x</Text>}
        <TouchableOpacity>
          <Text style={styles.editText}>Edit</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Ionicons name="menu" size={28} color="black" />
        <Text style={styles.headerTitle}>Order Produk</Text>
        <Ionicons name="notifications" size={28} color="black" />
      </View>

      {/* Customer List */}
      <View style={styles.customerContainer}>
        <Text style={styles.customerTitle}>Customer List</Text>
        <Text style={styles.seeAll}>Lihat semua</Text>
      </View>
      <FlatList
        data={['Heruswandi', 'Marimaris', 'Imas Masri', 'Michael']}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.customerTab}>
            <Text style={styles.customerTabText}>{item}</Text>
          </TouchableOpacity>
        )}
        keyExtractor={(item, index) => index.toString()}
      />

      {/* Search & Filter */}
      <View style={styles.searchContainer}>
        <TextInput placeholder="Cari produk..." style={styles.searchInput} />
        <Ionicons name="search" size={20} color="gray" style={styles.searchIcon} />
        <Ionicons name="options" size={20} color="gray" style={styles.filterIcon} />
      </View>

      {/* Categories */}
      <FlatList
        data={categories}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.categoryTab,
              selectedCategory === item.name && styles.selectedCategoryTab,
            ]}
            onPress={() => setSelectedCategory(item.name)}
          >
            <Text
              style={[
                styles.categoryTabText,
                selectedCategory === item.name && styles.selectedCategoryText,
              ]}
            >
              {item.name}
            </Text>
          </TouchableOpacity>
        )}
        keyExtractor={(item) => item.id}
      />

      {/* Products */}
      <FlatList
        data={products}
        renderItem={renderProduct}
        keyExtractor={(item) => item.id}
      />

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>Pesanan (2 item)</Text>
        <Text style={styles.footerTotal}>Rp. 20.000,00</Text>
        <Ionicons name="bag" size={20} color="white" />
      </View>

      {/* Floating Action Button */}
      <TouchableOpacity style={styles.fab}>
        <Ionicons name="add" size={28} color="white" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9f9f9' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  headerTitle: { fontSize: 18, fontWeight: 'bold' },
  customerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  customerTitle: { fontSize: 16, fontWeight: 'bold' },
  seeAll: { color: 'blue' },
  customerTab: { marginHorizontal: 8 },
  customerTabText: { padding: 8, color: 'gray', borderRadius: 8 },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    marginHorizontal: 16,
    marginVertical: 8,
  },
  searchInput: { flex: 1, padding: 8 },
  searchIcon: { marginHorizontal: 8 },
  filterIcon: { marginHorizontal: 8 },
  categoryTab: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginHorizontal: 8,
    borderRadius: 16,
    backgroundColor: '#e6e6e6',
  },
  selectedCategoryTab: { backgroundColor: '#007aff' },
  categoryTabText: { fontSize: 14, color: 'gray' },
  selectedCategoryText: { color: '#fff' },
  productRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 4,
    borderRadius: 8,
  },
  productName: { fontSize: 14, fontWeight: 'bold' },
  productPrice: { fontSize: 12, color: 'gray' },
  productActions: { flexDirection: 'row', alignItems: 'center' },
  productQuantity: { fontSize: 12, color: 'blue', marginRight: 8 },
  editText: { fontSize: 12, color: 'blue' },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#28A745", // Warna latar belakang seperti cartSection
    padding: 15,
    borderRadius: 50,
    margin: 15,
    width: 325,  // Sama seperti di cartSection untuk ukuran
    position: "absolute",  // Agar tetap di bagian bawah
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1,  // Agar tidak tertutup elemen lain
  },
  footerText: {
    color: "#fff", 
    fontSize: 14,
  },
  footerTotal: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    left: 15,
  },
  
  fab: {
    width: 50,
    height: 50,
    backgroundColor: "#007BFF", // Warna biru seperti tombol add
    borderRadius: 25, // Membuat tombol menjadi bulat
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    bottom: 16, // Posisi di bawah layar
    right:10, // Posisi di sisi kanan layar
  },
  
});

export default OrderScreen;
