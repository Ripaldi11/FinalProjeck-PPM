import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

const HomeScreen = () => {
  const transactions = [
    { id: '1', code: '21239172AKS231', date: 'Sab, Sep 24, 2024', amount: 'Rp. 320.000,00' },
    { id: '2', code: '21239172AKS230', date: 'Sab, Sep 24, 2024', amount: 'Rp. 350.000,00' },
    { id: '3', code: '21239172AKS229', date: 'Sab, Sep 24, 2024', amount: 'Rp. 500.000,00' },
  ];

  const renderHeader = () => (
    <View style={styles.header}>
      <TouchableOpacity>
        <Ionicons name="menu" size={24} color="#000" />
      </TouchableOpacity>
      <Text style={styles.headerTitle}>Dashboard</Text>
      <TouchableOpacity>
        <Ionicons name="notifications" size={24} color="#000" />
      </TouchableOpacity>
    </View>
  );

  const renderStats = () => (
    <View style={styles.statsContainer}>
      <View style={styles.statCard}>
        <Image source={require('../assets/p.png')} style={styles.logo} />
        <Text style={styles.statTitle}>Total Penjualan</Text>
        <Text style={styles.statValue}>1.200</Text>
        <View style={styles.statChangeContainer}>
          <Ionicons name="arrow-up" size={12} color="#28a745" />
          <Text style={styles.statChange}>1,2%</Text>
        </View>
        <Text style={styles.statDate}>Saturday, 06 Sep 2024</Text>
        <Text style={styles.statFooterValue}>1.300</Text>
      </View>
      <View style={styles.statCard}>
        <Image source={require('../assets/transaction.png')} style={styles.logo} />
        <Text style={styles.statTitle}>Total Pemasukan</Text>
        <Text style={styles.statValue}>Rp. 15,215,000</Text>
        <View style={styles.statChangeContainer}>
          <Ionicons name="arrow-up" size={12} color="#28a745" />
          <Text style={styles.statChange}>0,5%</Text>
        </View>
        <Text style={styles.statDate}>Saturday, 06 Sep 2024</Text>
        <Text style={styles.statFooterValue}>14,890,000</Text>
      </View>
    </View>
  );

  const renderTotalProduk = () => (
    <View style={styles.productContainer}>
      <Image source={require('../assets/product.png')} style={styles.productIcon} />
      <Text style={styles.productTitle}>Total Produk</Text>
      <Text style={styles.productValue}>120</Text>
    </View>
  );

  const renderHistoryTitle = () => (
    <Text style={styles.historyTitle}>History transaksi</Text>
  );

  const renderTransactionItem = ({ item }) => (
    <View style={styles.transactionItem}>
      <Text style={styles.transactionCode}>{item.code}</Text>
      <Text style={styles.transactionDate}>{item.date}</Text>
      <Text style={styles.transactionAmount}>{item.amount}</Text>
    </View>
  );

  return (
    <FlatList
      data={transactions}
      keyExtractor={(item) => item.id}
      renderItem={renderTransactionItem}
      ListHeaderComponent={() => (
        <>
          {renderHeader()}
          {renderStats()}
          {renderTotalProduk()}
          {renderHistoryTitle()}
        </>
      )}
      ListFooterComponent={() => (
        <TouchableOpacity>
          <Text style={styles.seeAll}>Lihat Semua</Text>
        </TouchableOpacity>
      )}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#fff',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  logo: {
    width: 40,
    height: 40,
    marginBottom: 10,
  },
  statTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 8,
    color: '#000',
  },
  statChangeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e6f7ee',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
    marginVertical: 4,
  },
  statChange: {
    fontSize: 12,
    color: '#28a745',
    marginLeft: 4,
  },
  statDate: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
  },
  statFooterValue: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  productIcon: {
    width: 50,
    height: 50,
    marginHorizontal: 8,
  },
  productContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 10,
    margin: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 2,
  },
  productTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 15,
  },
  seeAll: {
    fontSize: 14,
    marginLeft: 20,
  },
  productValue: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 8,
    marginLeft: 160,
  },
  historyTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginHorizontal: 16,
    marginTop: 16,
  },
  transactionItem: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    margin: 16,
    flexDirection: 'column',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 2,
  },
  transactionCode: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  transactionDate: {
    fontSize: 12,
    color: '#999',
    marginVertical: 4,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e90ff',
  },
});

export default HomeScreen;
