import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert } from "react-native";
import { useNavigation } from "@react-navigation/native";
import Ionicons from "react-native-vector-icons/Ionicons";

const ProfileScreen = () => {
  const navigation = useNavigation();

  // Static user data (you can replace it with dynamic data from login)
  const user = {
    name: "Nana Idol",
    email: "Nanaidol@gmail.com",
    profilePicture: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnDEDWYjO1F898npOBNiFosheUckKxA67oQB-FdWOX2oBdHOsIy6tEaKRTYC2rhDCDh4c&usqp=CAU", // Replace with actual image URL or path
    phone: "123-456-7890",
    address: "123 Main St, City, Country",
  };

  const handleLogout = () => {
    Alert.alert("Logged out", "You have been logged out successfully.");
    navigation.navigate("Login"); // Navigate to Login screen after logging out
  };

  return (
    <View style={styles.container}>
      <View style={styles.profileHeader}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={30} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Profile</Text>
        <TouchableOpacity onPress={() => navigation.navigate("Settings")}>
          <Ionicons name="settings" size={30} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Profile Picture and Info */}
      <View style={styles.profileContainer}>
        <Image source={{ uri: user.profilePicture }} style={styles.profilePicture} />
        <Text style={styles.username}>{user.name}</Text>
        <Text style={styles.email}>{user.email}</Text>
      </View>

      {/* User Info Section */}
      <View style={styles.infoContainer}>
        <View style={styles.infoCard}>
          <Ionicons name="call" size={22} color="#6a11cb" />
          <Text style={styles.infoText}>{user.phone}</Text>
        </View>
        <View style={styles.infoCard}>
          <Ionicons name="location" size={22} color="#6a11cb" />
          <Text style={styles.infoText}>{user.address}</Text>
        </View>
      </View>

      {/* Logout Button */}
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    backgroundColor: "#6a11cb", // Solid background color (purple)
  },
  profileHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    alignItems: "center",
    marginBottom: 30,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#fff",
  },
  profileContainer: {
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 30,
    marginHorizontal: 20,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 5,
    marginBottom: 25,
  },
  profilePicture: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 5,
    borderColor: "#6a11cb",
    marginBottom: 10,
  },
  username: {
    fontSize: 26,
    fontWeight: "700",
    color: "#333",
    marginBottom: 5,
  },
  email: {
    fontSize: 16,
    color: "#777",
    marginBottom: 20,
  },
  infoContainer: {
    marginHorizontal: 20,
    marginBottom: 30,
  },
  infoCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  infoText: {
    fontSize: 18,
    color: "#333",
    marginLeft: 15,
  },
  logoutButton: {
    backgroundColor: "#f44336",
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 30,
    alignSelf: "center",
    marginTop: 30,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },
  logoutText: {
    fontSize: 18,
    color: "#fff",
    fontWeight: "600",
  },
});

export default ProfileScreen;
