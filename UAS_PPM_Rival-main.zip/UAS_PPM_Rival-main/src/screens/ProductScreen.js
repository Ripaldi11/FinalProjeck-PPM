import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import { useNavigation } from "@react-navigation/native";

const ProductScreen = () => {
  const [selectedCustomer, setSelectedCustomer] = useState("Heruswandi");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [cartItems, setCartItems] = useState([]);
  const [clickedProducts, setClickedProducts] = useState({});
  const [customers] = useState([
    "Heruswandi",
    "Marimas",
    "Imas Masri",
    "Michael",
  ]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showMenu, setShowMenu] = useState(false);

  const navigation = useNavigation();

  const categories = ["All", "Minuman", "Cemilan", "Mie", "Permen", "Ice"];

  // Fetch data from MockAPI
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(
          "https://671a5c8aacf9aa94f6aa583f.mockapi.io/food"
        ); // Ganti dengan URL MockAPI Anda
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error("Failed to fetch products:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const handleAddToCart = (product) => {
    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === product.id);
      if (existingItem) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prev, { ...product, quantity: 1 }];
      }
    });
  };

  const handleImageClick = (productId) => {
    setClickedProducts((prev) => {
      const newCount = (prev[productId] || 0) + 1;
      return { ...prev, [productId]: newCount };
    });
  };

  const handleProductClick = (product) => {
    handleImageClick(product.id);
    handleAddToCart(product);
  };

  const handleEdit = () => {
    setShowMenu(false);
    navigation.navigate("EditProduct");
  };

  const handleDelete = async (productId) => {
    try {
      await fetch(
        `https://671a5c8aacf9aa94f6aa583f.mockapi.io/food/${productId}`,
        {
          method: "DELETE",
        }
      );
      setProducts((prev) => prev.filter((item) => item.id !== productId));
    } catch (error) {
      console.error("Failed to delete product:", error);
    }
  };
  const renderProduct = ({ item }) => {
    const clickCount = clickedProducts[item.id] || 0;
    return (
      <View style={styles.productCard}>
        <TouchableOpacity onPress={() => handleProductClick(item)}>
          <Image source={{ uri: item.image }} style={styles.productImage} />
          {clickCount > 1 && (
            <View style={styles.clickBadge}>
              <Text style={styles.badgeText}>{`${clickCount}x`}</Text>
            </View>
          )}
        </TouchableOpacity>
        <View style={styles.iconContainer}>
          <TouchableOpacity onPress={() => navigation.navigate("EditProduct", { product: item })}>
            <Ionicons name="create" size={24} color="#fff" style={styles.icon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleDelete(item.id)}>
            <Ionicons name="trash" size={24} color="#fff" style={styles.icon} />
          </TouchableOpacity>
        </View>
        <Text style={styles.productName}>{item.name}</Text>
        <Text style={styles.productPrice}>
          Rp. {item.price.toLocaleString("id-ID")},-
        </Text>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007BFF" />
        <Text>Loading products...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setShowMenu((prev) => !prev)}>
          <Ionicons name="ellipsis-vertical" size={24} color="#000" />
        </TouchableOpacity>
        {showMenu && (
          <View style={styles.menu}>
            <TouchableOpacity
              onPress={() => navigation.navigate("AddProduct")}
              style={styles.menuItem}
            >
              <Text style={styles.menuText}>Add</Text>
            </TouchableOpacity>
          </View>
        )}
        <Text style={styles.headerTitle}>Order Produk</Text>
        <Ionicons name="notifications" size={24} color="#000" />
      </View>

      <View style={styles.customerList}>
        <Text style={styles.sectionTitle}>Customer List</Text>
        <Text style={styles.viewAll}>Lihat semua</Text>
      </View>

      <FlatList
        data={customers}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.customerButton,
              selectedCustomer === item && styles.activeCustomer,
            ]}
            onPress={() => setSelectedCustomer(item)}
          >
            <Text
              style={[
                styles.customerText,
                selectedCustomer === item && styles.activeCustomerText,
              ]}
            >
              {item}
            </Text>
          </TouchableOpacity>
        )}
      />

      <View style={styles.searchBar}>
        <Ionicons name="search" size={29} color="#ccc" top={11} left={15} />
        <TextInput placeholder="Cari produk..." style={styles.searchInput} />
        <Ionicons name="menu" size={40} color="#ccc" left={47} />
      </View>

      <FlatList
        data={categories}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.categoryButton,
              selectedCategory === item && styles.activeCategory,
            ]}
            onPress={() => setSelectedCategory(item)}
          >
            <Text
              style={[
                styles.categoryText,
                selectedCategory === item && styles.activeCategoryText,
              ]}
            >
              {item}
            </Text>
          </TouchableOpacity>
        )}
      />

      <FlatList
        data={products}
        numColumns={2}
        keyExtractor={(item) => item.id}
        renderItem={renderProduct}
        contentContainerStyle={{
          justifyContent: "space-between",
          paddingBottom: 80,
        }}
      />

      {cartItems.length > 0 && (
        <View style={styles.cartSection}>
          <Text style={styles.cartText}>Pesanan ({cartItems.length} item)</Text>
          <Text style={styles.cartPrice}>
            {cartItems
              .reduce((total, item) => total + item.price * item.quantity, 0)
              .toLocaleString("id-ID")}
          </Text>
          <Ionicons name="bag" size={20} color="#fff" style={styles.cartIcon} />
          <TouchableOpacity style={styles.addButtonIcon}>
            <Ionicons name="add" size={25} color="#fff" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

// Styles for the Edit and Add screens
const styles = StyleSheet.create({
  container: {
    padding: 10,
    backgroundColor: "#fff",
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 15,
  },
  menu: {
    position: "absolute",
    top: 30,
    left: 0,
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 8,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  menuItem: {
    paddingVertical: 8,
    paddingHorizontal: 15,
  },
  menuText: {
    fontSize: 14,
    color: "#333",
  },
  searchBar: {
    flexDirection: "row",
    borderRadius: 200,
    margin: 15,
    width: 340,
    height: 47,
    borderWidth: 0.2,
    marginLeft: 4,
  },
  headerTitle: { fontSize: 18, fontWeight: "bold" },
  customerList: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 15,
  },
  sectionTitle: { fontSize: 16, fontWeight: "bold" },
  viewAll: { color: "#007BFF", fontSize: 14 },
  customerButton: {
    paddingHorizontal: 15,
    paddingBottom: 5,
    marginRight: 10,
  },
  activeCustomer: {
    borderBottomWidth: 2,
    borderBottomColor: "#007BFF",
  },
  customerText: {
    fontSize: 14,
    color: "#999",
  },
  activeCustomerText: {
    color: "#000",
    fontWeight: "bold",
  },
  searchInput: { flex: 1, padding: 8, fontSize: 17, left: 13 },
  categoryButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: "#F5F5F5",
    marginHorizontal: 5,
  },
  activeCategory: { backgroundColor: "#007BFF" },
  categoryText: { fontSize: 14 },
  activeCategoryText: { color: "#fff" },
  productCard: {
    width: "48%",
    backgroundColor: "#F5F5F5",
    borderRadius: 8,
    margin: 2,
    padding: 10,
    alignItems: "center",
    position: "relative", // For icon positioning
  },
  productImage: { width: 180, height: 180, borderRadius: 19 },
  productName: { fontSize: 14, fontWeight: "bold", marginVertical: 5 },
  productPrice: { fontSize: 14, color: "#888" },
  iconContainer: {
    position: "absolute",
    top: 10,
    right: 5,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    padding: 5,
    borderRadius: 15,
  },
  cartSection: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#28A745",
    padding: 15,
    borderRadius: 50,
    margin: 15,
    width: 325,
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1,
  },
  cartText: { color: "#fff", fontSize: 14 },
  cartPrice: { color: "#fff", fontWeight: "bold", fontSize: 16, left: 15 },
  cartIcon: { right: 10 },
  addButtonIcon: {
    width: 50,
    height: 50,
    backgroundColor: "#007BFF",
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    bottom: 2,
    right: -55,
  },
  clickBadge: {
    position: "absolute",
    top: 5,
    right: 130,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 5,
    paddingVertical: 2,
    paddingHorizontal: 6,
  },
  badgeText: {
    color: "#fff",
    fontWeight: "bold",
  },
});

export default ProductScreen;
