import SQLite from 'react-native-sqlite-storage';
import { Product } from '../types/types';

const db = SQLite.openDatabase(
  {
    name: 'productapp.db',
    location: 'default',
  },
  () => {
    console.log('Database opened successfully');
  },
  error => {
    console.error('Error opening database: ', error);
  },
);

// Initialize the database and create the 'products' table
export const initDatabase = () => {
  db.transaction(
    tx => {
      tx.executeSql(
        'CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price REAL, image TEXT, category TEXT, customer TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)',
        [],
        () => {
          console.log('Products table created successfully');
        },
        (tx, error) => {
          console.error('Error creating table: ', error);
        },
      );
    },
    error => {
      console.error('Transaction error: ', error);
    },
    () => {
      console.log('Transaction successful');
    },
  );
};

// Function to add a product
export const addProduct = (name: string, price: number, image: string, category: string, customer: string) => {
  return new Promise<number>((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        'INSERT INTO products (name, price, image, category, customer) VALUES (?, ?, ?, ?, ?)',
        [name, price, image, category, customer],
        (_, { insertId }) => resolve(insertId), // Resolve with insertId
        (_, error) => reject(error), // Reject on error
      );
    });
  });
};

// Function to get all products
export const getProducts = () => {
  return new Promise<Product[]>((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM products ORDER BY created_at DESC',
        [],
        (_, { rows }) => resolve(rows.raw()), // Resolve with all rows
        (_, error) => reject(error), // Reject on error
      );
    });
  });
};

// Function to update product details (e.g., price, category)
export const updateProduct = (id: number, name: string, price: number, image: string, category: string, customer: string) => {
  return new Promise<void>((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        'UPDATE products SET name = ?, price = ?, image = ?, category = ?, customer = ? WHERE id = ?',
        [name, price, image, category, customer, id],
        () => resolve(), // Resolve when the update is successful
        (_, error) => reject(error), // Reject on error
      );
    });
  });
};

// Function to delete a product by ID
export const deleteProduct = (id: number) => {
  return new Promise<void>((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        'DELETE FROM products WHERE id = ?',
        [id],
        () => resolve(), // Resolve when the product is deleted
        (_, error) => reject(error), // Reject on error
      );
    });
  });
};
